package com.esmatollah.design

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DesignApp() }
    }
}

@Composable
fun DesignApp() {
    var selectedTool by remember { mutableStateOf("متن") }
    var text by remember { mutableStateOf("عصمت الله طراحی") }
    var size by remember { mutableFloatStateOf(42f) }
    var bold by remember { mutableStateOf(false) }
    var threeD by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("عصمت الله طراحی", fontWeight = FontWeight.Bold) }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("متن", "فونت", "لایه‌ها", "خروجی").forEach { item ->
                        NavigationBarItem(
                            selected = selectedTool == item,
                            onClick = { selectedTool = item },
                            icon = { Text(if (item == "متن") "T" else if (item == "فونت") "A" else if (item == "لایه‌ها") "☰" else "↥") },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DesignCanvas(text, size, bold, threeD)

                when (selectedTool) {
                    "متن" -> TextPanel(
                        text, { text = it }, size, { size = it },
                        bold, { bold = it }, threeD, { threeD = it }
                    )
                    "فونت" -> FontPanel()
                    "لایه‌ها" -> LayersPanel()
                    "خروجی" -> ExportPanel()
                }
            }
        }
    }
}

@Composable
fun DesignCanvas(text: String, size: Float, bold: Boolean, threeD: Boolean) {
    Box(
        Modifier.fillMaxWidth().height(330.dp)
            .background(Color(0xFFF0F0F5), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFFD0D0D8), RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (threeD) {
            Text(text, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                color = Color.DarkGray, modifier = Modifier.offset(5.dp, 5.dp))
        }
        Text(text, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun TextPanel(
    text: String, onText: (String) -> Unit, size: Float, onSize: (Float) -> Unit,
    bold: Boolean, onBold: (Boolean) -> Unit, threeD: Boolean, on3D: (Boolean) -> Unit
) {
    OutlinedTextField(text, onText, Modifier.fillMaxWidth(), label = { Text("متن") })
    Text("اندازه: ${size.toInt()}sp")
    Slider(value = size, onValueChange = onSize, valueRange = 16f..96f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("پررنگ")
        Switch(checked = bold, onCheckedChange = onBold)
        Spacer(Modifier.width(20.dp))
        Text("سه‌بعدی")
        Switch(checked = threeD, onCheckedChange = on3D)
    }
}

@Composable
fun FontPanel() {
    val fonts = listOf("پیش‌فرض", "نسخ", "نستعلیق", "کوفی", "تزئینی")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("فونت‌ها", style = MaterialTheme.typography.titleMedium)
        Text("ساختار برنامه برای افزودن فونت‌های سفارشی آماده است.")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(fonts) { f ->
                AssistChip(onClick = {}, label = { Text(f) })
            }
        }
    }
}

@Composable
fun LayersPanel() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("لایه‌ها", style = MaterialTheme.typography.titleMedium)
        listOf("متن", "پس‌زمینه").forEachIndexed { i, item ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${i + 1}. $item")
                    Text("👁")
                }
            }
        }
    }
}

@Composable
fun ExportPanel() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("خروجی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = {}) { Text("ذخیره PNG") }
        OutlinedButton(onClick = {}) { Text("ذخیره JPG") }
        Text("در نسخه بعدی ذخیره واقعی تصویر و پروژه اضافه می‌شود.")
    }
}
